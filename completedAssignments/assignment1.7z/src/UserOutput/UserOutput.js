import React from 'react';

const userOutput = (props) => {
    return <div className="UserOutput">
        <p>Some text in paragraph 1 said {props.username}</p>
        <p>Some other text in paragraph 2</p>
    </div>
};

export default userOutput;