import React from "react"
import "./Chararacter.css"

const character = (props) => {
  return (<p onClick={props.click} className="CharComponent">{props.character}</p>)
}

export default character;