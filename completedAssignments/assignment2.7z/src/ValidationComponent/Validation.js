import React from "react"

const validation = (props) => {
  const message = props.input.length < 5 ? "Text too short" : "Text long enough"

  return (<p>{message}</p>)
}

export default validation;